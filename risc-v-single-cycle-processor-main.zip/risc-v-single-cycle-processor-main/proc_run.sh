vlog *.sv
vsim -c tb_processor -do "run -all"